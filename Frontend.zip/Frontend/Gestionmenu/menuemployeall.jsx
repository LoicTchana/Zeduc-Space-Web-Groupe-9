// Menuallcomponents
import React from 'react';
import GestionMenuemploye from './gestionmenuemploye';
import Footermenu from './menufooter';

const MenuDashboardEmploye = () => {
  return (
    <>
      <GestionMenuemploye/>
      <Footermenu/>
      
    </>
  );
};

export default MenuDashboardEmploye;