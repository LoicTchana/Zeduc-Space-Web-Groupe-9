// PromotionsPage.jsx
import React from 'react';

const PromotionsPage = () => {
  return (
    <div>
      <h2>Promotions</h2>
      <p>Voici toutes les promotions en cours.</p>
      {/*Contenu relatif aux promotions */}
    </div>
  );
};

export default PromotionsPage;
