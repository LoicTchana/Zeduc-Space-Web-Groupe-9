import React from 'react';
import Header from './Header';
import MainContent from './main';
import Footer from './footer';


function App() {
  return (
    <div>
      <Header />
      <MainContent/>
      <Footer/>
      
      {/* Autres composants ou contenu ici */}
    </div>
  );
}

export default App;
