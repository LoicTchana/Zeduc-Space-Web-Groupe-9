// Employeallcomponents
import React from 'react';
import GestionComptesEmployes from './gestionemploye';
import FootergestionEmploye from './footergestionemploye';

const gestionCompteEmploye = () => {
  return (
    <>
      <GestionComptesEmployes/>
      <FootergestionEmploye/>
      
    </>
  );
};

export default gestionCompteEmploye;